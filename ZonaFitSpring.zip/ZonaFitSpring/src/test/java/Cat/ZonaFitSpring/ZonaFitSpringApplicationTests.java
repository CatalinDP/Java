package Cat.ZonaFitSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZonaFitSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
